//package
package gui.travellingsalesman;

//imports
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class HelpController {
    //attributes and references
    private Stage stage;

    @FXML
    private AnchorPane ap;

    private Parent root;
    private Scene main;

    //method to switch to menu
    @FXML
    protected void switchSceneToMenu(ActionEvent event) throws IOException { //method's usage is called upon pressing "menu" button
        //loading fxml file as root
        root = FXMLLoader.load(getClass().getResource("menu-view.fxml")); //loads the menu fxmml file
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        main = new Scene(root); //creates a new scene object which will be the main menu
        stage.setScene(main); //sets the scene to the main menu
        stage.show(); //shows the main menu
    }

}

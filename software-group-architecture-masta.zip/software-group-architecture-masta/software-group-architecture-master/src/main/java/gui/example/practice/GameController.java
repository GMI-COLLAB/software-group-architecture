package gui.example.practice;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class GameController {
    private Stage stage;
    private Parent root;
    private Scene main;


    //Here is declaring all the images, labels and buttons we are using in the game as of now
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private ImageView currentBuilding;

    @FXML
    private ImageView unfoundRing;

    @FXML
    private ImageView spot22;

   @FXML
    private ImageView spot23;

    @FXML
    private Label wealth;

    @FXML
    private Button continueOnwards;

    @FXML
    private ImageView treasureSlot1;

    @FXML
    protected void switchSceneToMain(ActionEvent event) throws IOException { //method that opens the game view menu
        root = FXMLLoader.load(getClass().getResource("game-view.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        main = new Scene(root);
        stage.setScene(main);
        stage.show();
    }

    @FXML
    protected void switchSceneToHelp(ActionEvent event) throws IOException { //method that opens the game tutorial
        root = FXMLLoader.load(getClass().getResource("help-view.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        main = new Scene(root);
        stage.setScene(main);
        stage.show();
    }

    @FXML
    protected void switchSceneToMenu(ActionEvent event) throws IOException { //method that returns to the main menu
        root = FXMLLoader.load(getClass().getResource("menu-view.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        main = new Scene(root);
        stage.setScene(main);
        stage.show();
    }

    @FXML
    protected void endGame(ActionEvent event) throws IOException{ //quitting the game
        System.exit(0);
    }

    @FXML
    protected void moveToHouse(){ //very basic implementation of moving forwards, DEFINITELY subject to change
        //for example this is if you rolled 1 move up
        Image foundTreasure = new Image("dring.PNG");
        Image blank = new Image("blankSpot.PNG");
        Image icon = new Image("playerOnTreasure.png");
        Image ringCollected = new Image("dring1.PNG");
        unfoundRing.setImage(blank); //replaces unfound treasure with blank
        treasureSlot1.setImage(ringCollected); //shows the ring in the first treasure slot
        currentBuilding.setImage(foundTreasure); //shows pop up of finding treasure
        spot22.setImage(icon); //sets the character ontop of the house, and the other spot to blank
        spot23.setImage(blank);
    }

}